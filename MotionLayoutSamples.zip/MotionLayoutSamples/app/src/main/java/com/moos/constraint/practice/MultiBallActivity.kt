package com.moos.constraint.practice

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import com.moos.constraint.R

class MultiBallActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_multi_ball_layout)
    }
}