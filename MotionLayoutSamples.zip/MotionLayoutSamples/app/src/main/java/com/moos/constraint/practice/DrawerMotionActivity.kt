package com.moos.constraint.practice

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import com.moos.constraint.R
//todo:fix scroll problem
class DrawerMotionActivity: AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_motion_with_drawer)

    }

}